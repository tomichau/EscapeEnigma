Escape Enigma :

Comment lancer le jeu ? 
dans un terminale (alt + T) faire (tout en étant dans le dossier du jeu) : 
sh compile.sh 
puis
sh run.sh
(si vous faites celà dans le terminal de vs code par exemple, ça ne donnera pas le bon rendu).

Le but du jeu : 
Vous allez naviguer entre 3 salles (anglais, science et histoire). Après avoir passer ces 3 épreuves, vous serez libérer du manoir.

La sauvegarde est automatique, elle se fait quand vous finissez une salle.

Lorsque le bouton "suivant" apparaît en bas de votre écran, appuyez juste sur entrée pour acceder à la suite.

Escape Enigma - créé par Chaumette Thomas & Lelievre Tom.