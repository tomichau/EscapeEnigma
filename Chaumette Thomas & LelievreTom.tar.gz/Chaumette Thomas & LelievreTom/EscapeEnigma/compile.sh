#!/bin/sh
javac -cp lib/program.jar:. Jeu.java
