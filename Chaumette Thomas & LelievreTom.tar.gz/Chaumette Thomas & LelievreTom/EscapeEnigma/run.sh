#!/bin/sh
java -cp lib/program.jar:. Jeu
